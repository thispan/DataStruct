package com.data.lab1;

public class ArraySet extends ArrayCollection{
    public ArraySet(int c){
        super(c);
    }

    @Override
    public void add (Object e){
        if (e == null ) throw new IllegalArgumentException();
        if (!contains(e)){ //Chk ว่าไม่มีซ้ำ add เพิ่ม
            super.add(e); //เรียน method add ใน superclass (รึปะ?)
        }
    }

    public ArraySet union(ArraySet array){
        Object[] arr1 = array.toArray();
        Object[] arr2 = toArray();
        ArraySet ans = new ArraySet(array.size()); //Array คำตอบของ union
        for (int i=0; i < array.size() ;i++ ){ //วนตามขนาดอเรย์ใหม่
              ans.add(arr1[i]);
            }
        for (int i=0; i < super.size() ;i++ ){
            ans.add(arr2[i]);
        }
        return ans ;
    }

    public ArraySet intersection(ArraySet array) {
        ArraySet ans = new ArraySet(0);
        Object[] arr1 = array.toArray();
        for (int i = 0; i < array.size(); i++) {
            if (contains(arr1[i])) {
                ans.add(arr1[i]);
            }
        }
        return ans;
    }

    public boolean equals(ArraySet array) {
        Object[] arr1 = array.toArray();
        if (this.size() != array.size()) {
            return false;
        }
            for (int i = 0; i < array.size(); i++) {
                if (!this.contains(arr1[i])) {
                    return false;
                }
        }
            return true;

    }

}
