package com.data.lab1;

import java.util.Arrays;

public class ArraySetTest {
    public static void main(String[] args) {
        ArrayCollection set1 = new ArrayCollection(5);
        set1.add(4);
        set1.add(5);
        set1.add(6);
        set1.add(7);
        set1.add(8);
        ArraySet set2 = new ArraySet(4);
        set2.add(8);
        set2.add(9);
        set2.add(7);
        set2.add(5);
        ArraySet set3 = new ArraySet(3);
        set3.add(6);
        set3.add(7);
        set3.add(9);
        ArraySet set4 = new ArraySet(3);
        set4.add(6);
        set4.add(7);
        set4.add(5);
        System.out.println(Arrays.toString(set1.toArray()));
        System.out.println(Arrays.toString(set2.toArray()));
        System.out.println(Arrays.toString(set3.toArray()));
        System.out.println(Arrays.toString(set2.union(set3).toArray()));
        System.out.println(Arrays.toString(set2.intersection(set3).toArray()));
        System.out.println(set3.equals(set4));

    }
}
